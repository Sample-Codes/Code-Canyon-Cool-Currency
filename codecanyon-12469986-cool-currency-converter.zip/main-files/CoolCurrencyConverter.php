<?php
	class CoolCurrencyConverter{
		public $filters_str = "abcdefghijklmnopqrstuvwyz";
		public $currency_list = array(
			'AED'=> 'United Arab Emirates Dirham',
			'AFN'=> 'Afghan Afghani',
			'ALL'=> 'Albanian Lek',
			'AMD'=> 'Armenian Dram',
			'ANG'=> 'Netherlands Antillean Guilder',
			'AOA'=> 'Angolan Kwanza',
			'ARS'=> 'Argentine Peso',
			'AUD'=> 'Australian Dollar',
			'AWG'=> 'Aruban Florin',
			'AZN'=> 'Azerbaijani Manat',
			'BAM'=> 'Bosnia-Herzegovina Convertible Mark',
			'BBD'=> 'Barbadian Dollar',
			'BDT'=> 'Bangladeshi Taka',
			'BGN'=> 'Bulgarian Lev',
			'BHD'=> 'Bahraini Dinar',
			'BIF'=> 'Burundian Franc',
			'BMD'=> 'Bermudan Dollar',
			'BND'=> 'Brunei Dollar',
			'BOB'=> 'Bolivian Boliviano',
			'BRL'=> 'Brazilian Real',
			'BSD'=> 'Bahamian Dollar',
			//'BTC'=> 'Bitcoin',
			'BTN'=> 'Bhutanese Ngultrum',
			'BWP'=> 'Botswanan Pula',
			'BYR'=> 'Belarusian Ruble',
			'BZD'=> 'Belize Dollar',
			'CAD'=> 'Canadian Dollar',
			'CDF'=> 'Congolese Franc',
			'CHF'=> 'Swiss Franc',
			'CLF'=> 'Chilean Unit of Account',
			'CLP'=> 'Chilean Peso',
			'CNH'=> 'CNH',
			'CNY'=> 'Chinese Yuan',
			'COP'=> 'Colombian Peso',
			'CRC'=> 'Costa Rican Colón',
			'CUP'=> 'Cuban Peso',
			'CVE'=> 'Cape Verdean Escudo',
			'CZK'=> 'Czech Republic Koruna',
			'DEM'=> 'German Mark',
			'DJF'=> 'Djiboutian Franc',
			'DKK'=> 'Danish Krone',
			'DOP'=> 'Dominican Peso',
			'DZD'=> 'Algerian Dinar',
			'EGP'=> 'Egyptian Pound',
			'ERN'=> 'Eritrean Nakfa',
			'ETB'=> 'Ethiopian Birr',
			'EUR'=> 'Euro',
			'FIM'=> 'Finnish Markka',
			'FJD'=> 'Fijian Dollar',
			'FKP'=> 'Falkland Islands Pound',
			'FRF'=> 'French Franc',
			'GBP'=> 'British Pound',
			'GEL'=> 'Georgian Lari',
			'GHS'=> 'Ghanaian Cedi',
			'GIP'=> 'Gibraltar Pound',
			'GMD'=> 'Gambian Dalasi',
			'GNF'=> 'Guinean Franc',
			'GTQ'=> 'Guatemalan Quetzal',
			'GYD'=> 'Guyanaese Dollar',
			'HKD'=> 'Hong Kong Dollar',
			'HNL'=> 'Honduran Lempira',
			'HRK'=> 'Croatian Kuna',
			'HTG'=> 'Haitian Gourde',
			'HUF'=> 'Hungarian Forint',
			'IDR'=> 'Indonesian Rupiah',
			'IEP'=> 'Irish Pound',
			'ILS'=> 'Israeli New Sheqel',
			'INR'=> 'Indian Rupee',
			'IQD'=> 'Iraqi Dinar',
			'IRR'=> 'Iranian Rial',
			'ISK'=> 'Icelandic Króna',
			'ITL'=> 'Italian Lira',
			'JMD'=> 'Jamaican Dollar',
			'JOD'=> 'Jordanian Dinar',
			'JPY'=> 'Japanese Yen',
			'KES'=> 'Kenyan Shilling',
			'KGS'=> 'Kyrgystani Som',
			'KHR'=> 'Cambodian Riel',
			'KMF'=> 'Comorian Franc',
			'KPW'=> 'North Korean Won',
			'KRW'=> 'South Korean Won',
			'KWD'=> 'Kuwaiti Dinar',
			'KYD'=> 'Cayman Islands Dollar',
			'KZT'=> 'Kazakhstani Tenge',
			'LAK'=> 'Laotian Kip',
			'LBP'=> 'Lebanese Pound',
			'LKR'=> 'Sri Lankan Rupee',
			'LRD'=> 'Liberian Dollar',
			'LSL'=> 'Lesotho Loti',
			'LTL'=> 'Lithuanian Litas',
			'LVL'=> 'Latvian Lats',
			'LYD'=> 'Libyan Dinar',
			'MAD'=> 'Moroccan Dirham',
			'MDL'=> 'Moldovan Leu',
			'MGA'=> 'Malagasy Ariary',
			'MKD'=> 'Macedonian Denar',
			'MMK'=> 'Myanmar Kyat',
			'MNT'=> 'Mongolian Tugrik',
			'MOP'=> 'Macanese Pataca',
			'MRO'=> 'Mauritanian Ouguiya',
			'MUR'=> 'Mauritian Rupee',
			'MVR'=> 'Maldivian Rufiyaa',
			'MWK'=> 'Malawian Kwacha',
			'MXN'=> 'Mexican Peso',
			'MYR'=> 'Malaysian Ringgit',
			'MZN'=> 'Mozambican Metical',
			'NAD'=> 'Namibian Dollar',
			'NGN'=> 'Nigerian Naira',
			'NIO'=> 'Nicaraguan Córdoba',
			'NOK'=> 'Norwegian Krone',
			'NPR'=> 'Nepalese Rupee',
			'NZD'=> 'New Zealand Dollar',
			'OMR'=> 'Omani Rial',
			'PAB'=> 'Panamanian Balboa',
			'PEN'=> 'Peruvian Nuevo Sol',
			'PGK'=> 'Papua New Guinean Kina',
			'PHP'=> 'Philippine Peso',
			'PKR'=> 'Pakistani Rupee',
			'PLN'=> 'Polish Zloty',
			'PYG'=> 'Paraguayan Guarani',
			'QAR'=> 'Qatari Rial',
			'RON'=> 'Romanian Leu',
			'RSD'=> 'Serbian Dinar',
			'RUB'=> 'Russian Ruble',
			'RWF'=> 'Rwandan Franc',
			'SAR'=> 'Saudi Riyal',
			'SBD'=> 'Solomon Islands Dollar',
			'SCR'=> 'Seychellois Rupee',
			'SDG'=> 'Sudanese Pound',
			'SEK'=> 'Swedish Krona',
			'SGD'=> 'Singapore Dollar',
			'SHP'=> 'St. Helena Pound',
			'SKK'=> 'Slovak Koruna',
			'SLL'=> 'Sierra Leonean Leone',
			'SOS'=> 'Somali Shilling',
			'SRD'=> 'Surinamese Dollar',
			'STD'=> 'São Tomé &amp; Príncipe Dobra',
			'SVC'=> 'Salvadoran Colón',
			'SYP'=> 'Syrian Pound',
			'SZL'=> 'Swazi Lilangeni',
			'THB'=> 'Thai Baht',
			'TJS'=> 'Tajikistani Somoni',
			'TMT'=> 'Turkmenistani Manat',
			'TND'=> 'Tunisian Dinar',
			'TOP'=> 'Tongan Paʻanga',
			'TRY'=> 'Turkish Lira',
			'TTD'=> 'Trinidad &amp; Tobago Dollar',
			'TWD'=> 'New Taiwan Dollar',
			'TZS'=> 'Tanzanian Shilling',
			'UAH'=> 'Ukrainian Hryvnia',
			'UGX'=> 'Ugandan Shilling',
			'USD'=> 'United States Dollar',
			'UYU'=> 'Uruguayan Peso',
			'UZS'=> 'Uzbekistani Som',
			'VEF'=> 'Venezuelan Bolívar',
			'VND'=> 'Vietnamese Dong',
			'VUV'=> 'Vanuatu Vatu',
			'WST'=> 'Samoan Tala',
			'XAF'=> 'Central African CFA Franc',
			'XCD'=> 'East Caribbean Dollar',
			'XPF'=> 'CFP Franc',
			'YER'=> 'Yemeni Rial',
			'ZAR'=> 'South African Rand',
			'ZMW'=> 'Zambian Kwacha',
		);
		
		public $selected_currencies = array(
			'from'	=> 'USD',
			'to'	=> 'EUR',
		);
		
		public $majors_currencies = array('USD', 'EUR', 'GBP', 'CAD', 'JPY');
		
		public function calc($options = array()){
			if(!isset($options['from']) || !isset($options['to']) || !isset($options['amount']) || !isset($options['source'])){return false;}
			$response = false;
			switch($options['source']){
				case 'google';
					$url  = "http://www.google.com/finance/converter?a=".$options['amount']."&from=".$options['from']."&to=".$options['to']."";
					$data = @file_get_contents($url, true);
					
					if($data === false){return false;}
					
					preg_match("/<span class=bld>(.*)<\/span>/",$data, $converted);
					$result = preg_replace("/[^0-9.]/", "", $converted[1]);
					$response = round($result, 5);
				break;
			}
			return $response;
		}
		
		public function create($options = array()){
			$template		= isset($options['template'])	? $options['template'] : 'vertical';
			$color			= isset($options['color'])		? $options['color'] : 'blue';
			$border			= isset($options['border']) && in_array($options['border'], array(true, false))	? $options['border'] : true;
			$flags_folder	= "ccc-webroot/img/flags/";
			
			switch($color){
				case 'blue':
					$color_class = 'color-blue';
				break;
				case 'green':
					$color_class = 'color-green';
				break;
				case 'orange':
					$color_class = 'color-orange';
				break;
				case 'red':
					$color_class = 'color-red';
				break;
				case 'custom':
					$color_class = 'color-custom';
				break;
			}
			
			switch($border){
				case true:
					$border_class = 'border-ok';
				break;
				case false:
					$border_class = 'border-none';
				break;
			}
			
			$ccc_str = '';
			$ccc_str .= '<div class="cc-container '.$template.' '.$color_class.' '.$border_class.'">';
			$ccc_str .= '	<div class="cc-header">';
			$ccc_str .= '		<div class="cc-titre">Currency Converter</div>';
			$ccc_str .= '	</div>';
			$ccc_str .= '	<div class="cc-content">';
			$ccc_str .= '		<div class="currencies-inputs-container">';
			$ccc_str .= '			<div class="currency-input from">';
			$ccc_str .= '				<input type="hidden" class="currency-value" value="'.strtoupper($this->selected_currencies['from']).'">';
			$ccc_str .= '				<div class="input-label">From</div>';
			$ccc_str .= '				<div class="input-ligne">';
			$ccc_str .= '					<div class="selected-currency input-box">';
			$ccc_str .= '						<div class="currency-code-flag">';
			$ccc_str .= '							<div class="currency-flag"><img src="'.$flags_folder.strtolower($this->selected_currencies['from']).'.png"></div>';
			$ccc_str .= '							<div class="currency-code">'.$this->selected_currencies['from'].'</div>';
			$ccc_str .= '						</div>';
			$ccc_str .= '						<div class="currency-label">'.$this->currency_list[$this->selected_currencies['from']].'</div>';
			$ccc_str .= '					</div>';
			$ccc_str .= '					<div class="input-text-zone input-box">';
			$ccc_str .= '						<div class="placeholder">0</div>';
			$ccc_str .= '						<input type="text" class="text-input amount" value="1">';
			$ccc_str .= '					</div>';
			$ccc_str .= '				</div>';
			$ccc_str .= '			</div>';
			$ccc_str .= '			<div class="reverse-box">';
			$ccc_str .= '				<div class="reverse-btn"><i class="fa fa-exchange"></i></div>';
			$ccc_str .= '			</div>';
			$ccc_str .= '			<div class="currency-input to">';
			$ccc_str .= '				<input type="hidden" class="currency-value" value="'.strtoupper($this->selected_currencies['to']).'">';
			$ccc_str .= '				<div class="input-label">To</div>';
			$ccc_str .= '				<div class="input-ligne">';
			$ccc_str .= '					<div class="selected-currency input-box">';
			$ccc_str .= '						<div class="currency-code-flag">';
			$ccc_str .= '							<div class="currency-flag"><img src="'.$flags_folder.strtolower($this->selected_currencies['to']).'.png"></div>';
			$ccc_str .= '							<div class="currency-code">'.$this->selected_currencies['to'].'</div>';
			$ccc_str .= '						</div>';
			$ccc_str .= '						<div class="currency-label">'.$this->currency_list[$this->selected_currencies['to']].'</div>';
			$ccc_str .= '					</div>';
			$ccc_str .= '					<div class="input-text-zone input-box">';
			$ccc_str .= '						<div class="placeholder">0</div>';
			$ccc_str .= '						<input type="text" class="text-input amount" value="0">';
			$ccc_str .= '					</div>';
			$ccc_str .= '				</div>';
			$ccc_str .= '			</div>';
									if($template == "horizontal"){
			$ccc_str .= '				<div class="cc-clear-fix"></div>';
									}
			$ccc_str .= '			<div class="convert-btn boutton clickable">Convert</div>';
			$ccc_str .= '		</div>';
			$ccc_str .= '		<div class="preloader-container">';
			$ccc_str .= '			<div class="preloader">';
			$ccc_str .= '				<div class="currency from"><img src="'.$flags_folder.strtolower($this->selected_currencies['from']).'.png"></div>';
			$ccc_str .= '				<div class="currency to"><img src="'.$flags_folder.strtolower($this->selected_currencies['to']).'.png"></div>';
			$ccc_str .= '			</div>';
			$ccc_str .= '		</div>';
			$ccc_str .= '		<div class="currencies-selectors">';
			$ccc_str .= '			<div class="selector-container from">';
			$ccc_str .= '				<div class="currencies-filters">';
			$ccc_str .= '					<ul>';
												for($i=0; $i < strlen($this->filters_str);$i++){
			$ccc_str .= 								'<li class="filter letter" data-filter="'.$this->filters_str[$i].'">'.$this->filters_str[$i].'</li>';
												}
			$ccc_str .= '						<li class="filter label" data-filter="majors">majors</li>';
			$ccc_str .= '					</ul>';
			$ccc_str .= '				</div>';
			$ccc_str .= '				<div class="currencies-list">';
			$ccc_str .= '					<ul>';
												foreach($this->currency_list as $currency_code=>$currency){
			$ccc_str .= '						<li class="currency'.(in_array(strtoupper($currency_code), $this->majors_currencies) ? ' major' : '').($this->selected_currencies['to'] == strtoupper($currency_code) ? ' reverse' : '').'" data-currency-code="'.$currency_code.'">';
			$ccc_str .= '							<div class="input-box">';
			$ccc_str .= '						 		<div class="currency-code-flag">';
			$ccc_str .= '							 		<div class="currency-flag"><img src="'.$flags_folder.strtolower($currency_code).'.png"></div>';
			$ccc_str .= '									<div class="currency-code">'.$currency_code.'</div>';
			$ccc_str .= '						 		</div>';
			$ccc_str .= '						 		<div class="currency-label">'.$currency.'</div>';
			$ccc_str .= '						 	</div>';
			$ccc_str .= '						 </li>';
												}
			$ccc_str .= '						<div class="cc-clear-fix"></div>';
			$ccc_str .= '					</ul>';
			$ccc_str .= '				</div>';
			$ccc_str .= '			</div>';
			$ccc_str .= '			<div class="selector-container to">';
			$ccc_str .= '				<div class="currencies-filters">';
			$ccc_str .= '					<ul>';
												for($i=0; $i < strlen($this->filters_str);$i++){
			$ccc_str .= '						<li class="filter letter" data-filter="'.$this->filters_str[$i].'">'.$this->filters_str[$i].'</li>';
												}
			$ccc_str .= '						<li class="filter label" data-filter="majors">majors</li>';
			$ccc_str .= '					</ul>';
			$ccc_str .= '				</div>';
			$ccc_str .= '				<div class="currencies-list">';
			$ccc_str .= '					<ul>';
											foreach($this->currency_list as $currency_code=>$currency){
			$ccc_str .= '						<li class="currency'.(in_array(strtoupper($currency_code), $this->majors_currencies) ? ' major' : '').($this->selected_currencies['from'] == strtoupper($currency_code) ? ' reverse' : '').'" data-currency-code="'.$currency_code.'">';
			$ccc_str .= '						 	<div class="input-box">';
			$ccc_str .= '								<div class="currency-code-flag">';
			$ccc_str .= '						 			<div class="currency-flag"><img src="'.$flags_folder.strtolower($currency_code).'.png"></div>';
			$ccc_str .= '						 			<div class="currency-code">'.$currency_code.'</div>';
			$ccc_str .= '						 		</div>';
			$ccc_str .= '						 		<div class="currency-label">'.$currency.'</div>';
			$ccc_str .= '						 	</div>';
			$ccc_str .= '						 </li>';
											}
			$ccc_str .= '					</ul>';
			$ccc_str .= '				</div>';
			$ccc_str .= '			</div>';
			$ccc_str .= '		</div>';
			$ccc_str .= '	</div>';
			$ccc_str .= '</div>';
            
			echo $ccc_str;
		}
	}
?>