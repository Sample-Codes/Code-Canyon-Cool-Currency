<?php
	$ajaxData = json_decode($_POST['data']);
	$serverResponse = array('serverResponse' => 0, 'result' => 0);
	
	if(isset($ajaxData->fromCurrency) && isset($ajaxData->toCurrency) && isset($ajaxData->amount)){
		require_once "CoolCurrencyConverter.php";
		$CoolCurrencyConverter = new CoolCurrencyConverter();
		$result = $CoolCurrencyConverter->calc(array(
				'from'		=> strtoupper($ajaxData->fromCurrency),
				'to' 		=> strtoupper($ajaxData->toCurrency),
				'amount'	=> $ajaxData->amount,
				'source'	=> 'google'
			)
		);
		
		if($result != false){
			$serverResponse['serverResponse']	= 1;
			$serverResponse['result']			= $result;
		}
	}
	
	echo json_encode($serverResponse);
?>