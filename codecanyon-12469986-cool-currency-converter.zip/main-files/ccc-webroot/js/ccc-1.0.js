$(function(){
	$.fn.coolCurrencyConverter = {
		config : {
			ajax_url : 'ajax.php',
		},
		
		create : function(){
			this.init();
		},
		
		init : function(){
			this.hundlers();
			this.adjust();
		},
		
		hundlers : function(){
			$('body').on('click', '.cc-container .cc-content .currencies-inputs-container .currency-input .input-ligne .selected-currency', function(){
				$.fn.coolCurrencyConverter.actions.showCurrenciesContainer($(this));
			});
			
			$('body').on('click', '.cc-container .cc-content .currencies-selectors .selector-container .currencies-list ul li.currency', function(){
				$.fn.coolCurrencyConverter.actions.changeCurrency($(this));
			});
			
			$(document).on('keydown', function(e){
				if (e.keyCode === 27){//SC
					$(".cc-container").each(function(){
						$currencies_inputs_container	= $(".currencies-inputs-container", $(this));
						$currencies_selectors_container	= $(".currencies-selectors", $(this));
						
						$currencies_inputs_container.slideDown(700);
						$('.selector-container.current', $currencies_selectors_container).slideUp(500, function(){
							$currencies_selectors_container.hide();
						});
					});
				}
			});
			
			$('body').on('click', '.cc-container .cc-content .currencies-inputs-container .reverse-box .reverse-btn', function(){
				$.fn.coolCurrencyConverter.actions.reverseCurrencies($(this));
			});
			
			$('body').on('click', '.cc-container .cc-content .currencies-selectors .selector-container .currencies-filters ul li', function(){
				$.fn.coolCurrencyConverter.actions.filterCurrencies($(this));
			});
			
			$('body').on('keyup', '.cc-container .cc-content .currencies-inputs-container .currency-input .input-ligne .input-text-zone .text-input', function(e){
				$.fn.coolCurrencyConverter.actions.inputTextZoneAdjust($(this), "keyup");
			});
			
			$('body').on('change', '.cc-container .cc-content .currencies-inputs-container .currency-input .input-ligne .input-text-zone .text-input', function(e){
				$.fn.coolCurrencyConverter.actions.inputTextZoneAdjust($(this), "change");
			});
			
			$('body').on('mouseup', '.cc-container .cc-content .currencies-inputs-container .convert-btn', function(e){
				$.fn.coolCurrencyConverter.actions.convert($(this));
			});
			
			//Effects
			$("body").on("mousedown", '.clickable', function(e){
				$.fn.coolCurrencyConverter.actions.clickable($(this), e);
			});
		},
		adjust : function(){
			$('.cc-container .cc-content .currencies-inputs-container .currency-input .input-ligne .input-text-zone .text-input').each(function(){
				$.fn.coolCurrencyConverter.actions.inputTextZoneAdjust($(this));
			});
		},
		actions : {
			showCurrenciesContainer : function($selected_currency){
				var selector = $selected_currency.parents(".currency-input").is(".from") ? 'from' : 'to';
				$currencies_inputs_container	= $selected_currency.parents(".currencies-inputs-container");
				$currencies_selectors_container	= $(".currencies-selectors", $selected_currency.parents(".cc-container"));
				
				$('.selector-container', $currencies_selectors_container).removeClass("current");
				$('.selector-container.'+selector, $currencies_selectors_container).addClass("current");
				
				$currencies_inputs_container.slideUp(400);
				$currencies_selectors_container.show();
				$('.selector-container', $currencies_selectors_container).hide();
				$('.selector-container.'+selector, $currencies_selectors_container).slideDown(700);
			},
			
			changeCurrency : function($selected_currency){
				var selector = $selected_currency.parents(".selector-container").is(".from") ? 'from' : 'to';
				$currencies_inputs_container	= $(".currencies-inputs-container", $selected_currency.parents(".cc-container"));
				$currencies_selectors_container	= $selected_currency.parents(".currencies-selectors");
				$preloader_container			= $(".preloader-container", $selected_currency.parents(".cc-container"));
				
				//update currency code
				var selectedCurrencyCode = $selected_currency.data('currency-code');
				$(".currency-input."+selector+" .currency-value", $currencies_inputs_container).val(selectedCurrencyCode);
				
				//update curency html
				var selectedCurrencyHtml = $('.input-box', $selected_currency).html();
				$(".currency-input."+selector+" .input-ligne .selected-currency.input-box", $currencies_inputs_container).hide().html(selectedCurrencyHtml).fadeIn(1200);
				
				//update preloader
				var selectedCurrencyFlgHtml = $('.input-box .currency-code-flag .currency-flag', $selected_currency).html();
				$(".preloader .currency."+selector, $preloader_container).html(selectedCurrencyFlgHtml);
				
				//hide choosed currency from reverse list
				$(".selector-container."+(selector == 'from' ? 'to' : 'from')+" .currencies-list ul li.currency", $currencies_selectors_container).removeClass('reverse');
				$(".selector-container."+(selector == 'from' ? 'to' : 'from')+" .currencies-list ul li.currency[data-currency-code="+selectedCurrencyCode+"]", $currencies_selectors_container).addClass('reverse');
				
				
				$('.selector-container', $currencies_selectors_container).removeClass("current");
				$(".currencies-list ul li.currency", $('.selector-container.'+selector, $currencies_selectors_container)).removeClass("selected");
				$selected_currency.addClass("selected");
				
				$currencies_inputs_container.slideDown(700);
				$('.selector-container.'+selector, $currencies_selectors_container).slideUp(500, function(){
					$currencies_selectors_container.hide();
				});
			},
			
			reverseCurrencies : function($reverse_btn){
				$currencies_inputs_container	= $(".currencies-inputs-container", $reverse_btn.parents(".cc-container"));
				$currencies_selectors_container	= $(".currencies-selectors", $reverse_btn.parents(".cc-container"));
				var data = new Object();
				
				//collect Html & values
				data.fromCurrencyCode	= $(".currency-input.from .currency-value", $currencies_inputs_container).val();
				data.fromHtml			= $(".currency-input.from .input-ligne .selected-currency.input-box", $currencies_inputs_container).html();
				data.toCurrencyCode		= $(".currency-input.to .currency-value", $currencies_inputs_container).val();
				data.toHtml				= $(".currency-input.to .input-ligne .selected-currency.input-box", $currencies_inputs_container).html();
				
				//set changes
				$(".currency-input.from .currency-value", $currencies_inputs_container).val(data.toCurrencyCode);
				$(".currency-input.from .input-ligne .selected-currency.input-box", $currencies_inputs_container).css({'opacity':0}).html(data.toHtml).animate({'opacity':1}, 800);
				$(".currency-input.to .currency-value", $currencies_inputs_container).val(data.fromCurrencyCode);
				$(".currency-input.to .input-ligne .selected-currency.input-box", $currencies_inputs_container).css({'opacity':0}).html(data.fromHtml).animate({'opacity':1}, 800);
				
				//hide selected currencies from reverse lists
				$(".selector-container .currencies-list ul li.currency", $currencies_selectors_container).removeClass('reverse');
				$(".selector-container.from .currencies-list ul li.currency[data-currency-code="+data.fromCurrencyCode+"]", $currencies_selectors_container).addClass('reverse');
				$(".selector-container.to .currencies-list ul li.currency[data-currency-code="+data.toCurrencyCode+"]", $currencies_selectors_container).addClass('reverse');
			},
			
			filterCurrencies : function($filterButton){
				$currencies_selectors_container	= $filterButton.parents(".currencies-selectors");
				var selector = $filterButton.parents(".selector-container").is(".from") ? 'from' : 'to';
				var filter = new Object();
				
				filter.type		= $filterButton.is(".letter") ? "letter" : 'label';
				filter.value	= $filterButton.data('filter');
				
				if(filter.type == "label"){
					switch(filter.value){
						case 'majors':
							$('.selector-container.'+selector+' .currencies-list ul li.currency', $currencies_selectors_container).fadeOut(400);
							$('.selector-container.'+selector+' .currencies-list ul li.currency.major', $currencies_selectors_container).not('.reverse').fadeIn(400);
						break;
					};
				}else{
					$('.selector-container.'+selector+' .currencies-list ul li.currency', $currencies_selectors_container).each(function(){
						if(!$(this).is('.reverse')){
							var filter_reg = new RegExp("^"+(filter.value).toLowerCase(),"gi");
							if(filter_reg.test($('.input-box .currency-label', $(this)).text().toLowerCase()) || filter_reg.test($('.input-box .currency-code-flag .currency-code', $(this)).text().toLowerCase())){
								$(this).show();
							}else{
								$(this).hide();
							}
						}
					});
				}
			},
			
			inputTextZoneAdjust : function($textInput, eventStr){
				//format input value
				var value = $textInput.val().replace(/[^0-9$.]/g, '').replace( /^([^.]*\.)(.*)$/, function (a, b, c) { 
					return b + c.replace( /\./g, '' );
				});
				
				if(eventStr == "change"){
					value = value == '' ? '1' : value;
				}
				$textInput.val(value);
			},
			
			convert : function($convertButton){
				$currencies_inputs_container	= $(".currencies-inputs-container", $convertButton.parents(".cc-container"));
				$preloader_container			= $(".preloader-container", $convertButton.parents(".cc-container"));
				
				var data = new Object();
				data.fromCurrency	= $(".currency-input.from .currency-value", $currencies_inputs_container).val();
				data.toCurrency		= $(".currency-input.to .currency-value", $currencies_inputs_container).val();
				data.amount			= $(".currency-input.from .input-ligne .input-text-zone input.amount", $currencies_inputs_container).val();
				
				var convertion = $.ajax({
					type: "POST",
					url: $.fn.coolCurrencyConverter.config.ajax_url,
					data: {
						data: JSON.stringify(data)
					},
					beforeSend: function( xhr ){
						$preloader_container.fadeIn(400);
					}
				})
				.done(function(serverResponse){
					$preloader_container.fadeOut(400);
					var JSONserverResponse = $.parseJSON(serverResponse);
					if(JSONserverResponse.serverResponse == '1'){
						$(".currency-input.to .input-ligne .input-text-zone input.amount", $currencies_inputs_container).fadeOut(300, function(){
							$(this).val(JSONserverResponse.result).fadeIn(700);
						});
					}
					
				})
				.fail(function(jqXHR, textStatus){
					$preloader_container.fadeOut(400);
					console.log(textStatus);
				})
				.always(function() {
					$preloader_container.fadeOut(400);
				});
			},
			
			clickable : function(element, event){
				options = new Object();
				options.from = new Object();
				options.to = new Object();
				options.from.diametre	= 0;
				options.from.left		= (event.pageX - element.offset().left);
				options.from.top		= (event.pageY - element.offset().top);
				options.to.diametre		= (event.pageX - element.offset().left)>(element.outerWidth()/2) ? (event.pageX - element.offset().left)*2 : (element.outerWidth() - (event.pageX - element.offset().left))*2;
				options.to.left			= (event.pageX - element.offset().left)-(options.to.diametre/2);
				options.to.top			= (event.pageY - element.offset().top)-(options.to.diametre/2);
				
				
				if(!$('.ccc-effects-container', element).length){
					$("<div>", {
						class : 'ccc-effects-container'
					}).appendTo(element);
				}
				
				$("<div>", {
					class : 'ccc-propagation-effect'
				}).css({"width" : options.from.diametre, "height" : options.from.diametre, "left":options.from.left, "top":options.from.top, "opacity" : ".2"}).appendTo($('.ccc-effects-container', element))
				.animate({"width" : options.to.diametre, "height" : options.to.diametre, "left":options.to.left, "top":options.to.top, "opacity" : "0"}, {duration:550}).animate({"opacity" : "0"}, {duration:750, complete:function(){
					$(this).remove();
				}});
			}
		}
	}
	
	$.fn.coolCurrencyConverter.create();
});